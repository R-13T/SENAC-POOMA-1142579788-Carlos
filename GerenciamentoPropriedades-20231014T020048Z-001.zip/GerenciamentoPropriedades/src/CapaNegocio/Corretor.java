
package CapaNegocio;

public class Corretor {
  
    protected String nome_corretor;
    protected String sobrenome_corretor;
    protected String cpf_corretor;
    protected String telefone_corretor; 
    protected String email_corretor;
    protected String departamento_corretor;
    protected String funcao_corretor;
    
    

    
    public Corretor() {        
        this.nome_corretor = "Felipe";
        this.sobrenome_corretor = "Chang";
        this.cpf_corretor = "90083292344";
        this.telefone_corretor = "11932876444";
        this.email_corretor = "felipe.corretor@gmail.com";
        this.departamento_corretor = "Ventas";
        this.funcao_corretor = "corretor";
    }
}
