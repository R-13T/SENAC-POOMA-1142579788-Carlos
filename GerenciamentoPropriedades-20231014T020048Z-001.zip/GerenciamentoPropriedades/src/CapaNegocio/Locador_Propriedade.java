
package CapaNegocio;


public class Locador_Propriedade {
    
    protected String nome_locador;
    protected String sobrenome_locador;
    protected String cpf_locador;
    protected String telefone_locador; 
    protected String email_locador;
   

    public Locador_Propriedade() {
        this.nome_locador = "Rodrigo";
        this.sobrenome_locador = "Ramirez";
        this.cpf_locador = "40897765411";
        this.telefone_locador = "11983756888";
        this.email_locador = "rodrigoramirez@gmail.com";        
        
    }
    
    
    
}
