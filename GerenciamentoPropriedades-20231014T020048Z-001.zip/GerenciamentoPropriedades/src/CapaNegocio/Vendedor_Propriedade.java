
package CapaNegocio;


public class Vendedor_Propriedade {
    protected String nome_vendedor_prop;
    protected String sobrenome_vendedor_prop;
    protected String cpf_vendedor_prop;
    protected String telefone_vendedora_prop; 
    protected String email_vendedor_prop;

    public Vendedor_Propriedade() {
        this.nome_vendedor_prop = "Kevin";
        this.sobrenome_vendedor_prop = "Galvez";
        this.cpf_vendedor_prop = "87391238911";
        this.telefone_vendedora_prop = "1193999888123";
        this.email_vendedor_prop = "kevingalvez@gmail.com";
    }

}
