
package CapaNegocio;


public class Propriedade_Venta extends Corretor{
    
    protected String endereco_propriedade_vent;
    protected String numero_propriedade_vent;
    protected String complemento_propriedade_vent;
    protected String ciudade_propriedade_vent;
    protected String barrio_propriedade_vent;
    protected String preco_propriedade_vent;
    protected String tipo_inmovel_propiedade_vent;
    protected String estado_propriedade_vent;//definir

    public Propriedade_Venta(){
        this.endereco_propriedade_vent = "Alexandre Benois";
        this.numero_propriedade_vent = "17";
        this.complemento_propriedade_vent = "44a";
        this.ciudade_propriedade_vent = "São Paulo";
        this.barrio_propriedade_vent = "Vila Andrade";
        this.preco_propriedade_vent = "900000";
        this.tipo_inmovel_propiedade_vent = "casa";
        this.estado_propriedade_vent = "disponivel";
    }

    public String getEndereco_propriedade_vent() {
        return endereco_propriedade_vent;
    }

    public void setEndereco_propriedade_vent(String endereco_propriedade_vent) {
        this.endereco_propriedade_vent = endereco_propriedade_vent;
    }

    public String getNumero_propriedade_vent() {
        return numero_propriedade_vent;
    }

    public void setNumero_propriedade_vent(String numero_propriedade_vent) {
        this.numero_propriedade_vent = numero_propriedade_vent;
    }

    public String getComplemento_propriedade_vent() {
        return complemento_propriedade_vent;
    }

    public void setComplemento_propriedade_vent(String complemento_propriedade_vent) {
        this.complemento_propriedade_vent = complemento_propriedade_vent;
    }

    public String getCiudade_propriedade_vent() {
        return ciudade_propriedade_vent;
    }

    public void setCiudade_propriedade_vent(String ciudade_propriedade_vent) {
        this.ciudade_propriedade_vent = ciudade_propriedade_vent;
    }

    public String getBarrio_propriedade_vent() {
        return barrio_propriedade_vent;
    }

    public void setBarrio_propriedade_vent(String barrio_propriedade_vent) {
        this.barrio_propriedade_vent = barrio_propriedade_vent;
    }

    public String getPreco_propriedade_vent() {
        return preco_propriedade_vent;
    }

    public void setPreco_propriedade_vent(String preco_propriedade_vent) {
        this.preco_propriedade_vent = preco_propriedade_vent;
    }

    public String getTipo_inmovel_propiedade_vent() {
        return tipo_inmovel_propiedade_vent;
    }

    public void setTipo_inmovel_propiedade_vent(String tipo_inmovel_propiedade_vent) {
        this.tipo_inmovel_propiedade_vent = tipo_inmovel_propiedade_vent;
    }

    public String getEstado_propriedade_vent() {
        return estado_propriedade_vent;
    }

    public void setEstado_propriedade_vent(String estado_propriedade_vent) {
        this.estado_propriedade_vent = estado_propriedade_vent;
    }
    
    public void imprimir_corretor_agendado() {//ver que mudar
        System.out.println("Nome do corretor: " + super.nome_corretor);
        System.out.println("Sobrenome do corretor: " + super.sobrenome_corretor);
        System.out.println("Telefone do corretor: " + super.telefone_corretor);
        System.out.println("O endereço da inmovel é: " + this.endereco_propriedade_vent);
        System.out.println("O numero do inmovel é: " + this.numero_propriedade_vent);
        System.out.println("O complemento do inmovel é: " + this.complemento_propriedade_vent);
        System.out.println("O tipo de inmovel é: " + this.tipo_inmovel_propiedade_vent);
        System.out.println("O barrio do inmovel é: " + this.barrio_propriedade_vent);
        System.out.println("Valor do inmovel é: " + this.preco_propriedade_vent);
    }
}
