package CapaNegocio;

public class Contrato_Venta_Inmovel extends Propriedade_Venta{

    protected String numero_documento_vent;
    protected String fecha_documento_vent;
    protected String firma_proprietario_vent;
    protected String firma_cliente_vent;
    protected String firma_corretor_vent;

    public Contrato_Venta_Inmovel() {
        this.numero_documento_vent = "0001231";
        this.fecha_documento_vent = "13/10/2023";
        this.firma_proprietario_vent = "1/0";
        this.firma_cliente_vent = "1/0";
        this.firma_corretor_vent = "1/0";
    }

    public String getNumero_documento_vent() {
        return numero_documento_vent;
    }

    public void setNumero_documento_vent(String numero_documento_vent) {
        this.numero_documento_vent = numero_documento_vent;
    }

    public String getFecha_documento_vent() {
        return fecha_documento_vent;
    }

    public void setFecha_documento_vent(String fecha_documento_vent) {
        this.fecha_documento_vent = fecha_documento_vent;
    }

    public String getFirma_proprietario_vent() {
        return firma_proprietario_vent;
    }

    public void setFirma_proprietario_vent(String firma_proprietario_vent) {
        this.firma_proprietario_vent = firma_proprietario_vent;
    }

    public String getFirma_cliente_vent() {
        return firma_cliente_vent;
    }

    public void setFirma_cliente_vent(String firma_cliente_vent) {
        this.firma_cliente_vent = firma_cliente_vent;
    }

    public String getFirma_corretor_vent() {
        return firma_corretor_vent;
    }

    public void setFirma_corretor_vent(String firma_corretor_vent) {
        this.firma_corretor_vent = firma_corretor_vent;
    }

    public void imprimir_contrato_venta_inmovel(){
        System.out.println("Número do documento: " + this.numero_documento_vent);
        System.out.println("Data do contrato: " + this.fecha_documento_vent);
        System.out.println("Firma do Clinte: " + this.firma_cliente_vent);
        System.out.println("Firma do Corretor: " + this.firma_corretor_vent);
        System.out.println("Firma do Proprietario: " + this.firma_proprietario_vent);
    }
    
    public static void main(String[] args) {
        Propriedade_Venta propven = new Propriedade_Venta();
        propven.imprimir_corretor_agendado();
        Contrato_Venta_Inmovel covein = new Contrato_Venta_Inmovel();
        covein.imprimir_contrato_venta_inmovel();
    }
}
