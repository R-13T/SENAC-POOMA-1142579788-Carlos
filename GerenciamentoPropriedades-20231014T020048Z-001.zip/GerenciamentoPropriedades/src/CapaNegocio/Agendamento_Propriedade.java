package CapaNegocio;


public class Agendamento_Propriedade extends Cliente{
    
    public static void main(String[] args) {
        System.out.println("Dados do Corretor e inmovel solicitado: ");       
        Propriedade_Alugueo agend = new Propriedade_Alugueo();        
        agend.imprimir_corretor_agendado();
        System.out.println("--------------------------------------- ");
        System.out.println("Dados do cliente:");
        System.out.println("--------------------------------------- ");
        Cliente cli = new Cliente();
        cli.imprimir_cliente();
        
    }
    
}
