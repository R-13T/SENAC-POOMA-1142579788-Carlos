
package CapaNegocio;


public class Cliente {
    
    protected String nome_cliente;
    protected String sobrenome_cliente;
    protected String cpf_cliente;
    protected String telefone_cliente;    
    protected String cidade;
    protected String barrio;
    protected String valor_total_ate;
    protected String numero_quartos;

  
    public Cliente() {
        
        this.nome_cliente = "Pedro";
        this.sobrenome_cliente = "Gonzales";
        this.cpf_cliente = "90032187698";
        this.telefone_cliente = "11932292339";
        this.cidade = "Rio de Janeiro";
        this.barrio = "Lapa";
        this.valor_total_ate = "1000000" ;
        this.numero_quartos = "5";
    }
    
    public void imprimir_cliente() {
        System.out.println("Nome Cliente: " + this.nome_cliente);
        System.out.println("Sobrenome Cliente: " + this.sobrenome_cliente);
    }
}
