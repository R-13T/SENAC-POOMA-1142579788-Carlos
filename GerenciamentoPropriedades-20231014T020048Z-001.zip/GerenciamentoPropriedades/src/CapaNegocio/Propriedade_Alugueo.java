package CapaNegocio;

public class Propriedade_Alugueo extends Corretor {

    protected String endereco_propriedade_alu;
    protected String numero_propriedade_alu;
    protected String complemento_propriedade_alu;
    protected String ciudade_propriedade_alu;
    protected String barrio_propriedade_alu;
    protected String preco_propriedade_alu;
    protected String tipo_inmovel_propiedade_alu;
    protected String estado_propriedade_alu;

    public Propriedade_Alugueo() {

        this.endereco_propriedade_alu = "Nelson gama de Oliveira";
        this.numero_propriedade_alu = "165";
        this.complemento_propriedade_alu = "31b";
        this.ciudade_propriedade_alu = "São Paulo";
        this.barrio_propriedade_alu = "Vila Andrade";
        this.preco_propriedade_alu = "360000";
        this.tipo_inmovel_propiedade_alu = "apartamento";
        this.estado_propriedade_alu = "disponivel";

    }

    public String getEndereco_propriedade_alu() {
        return endereco_propriedade_alu;
    }

    public void setEndereco_propriedade_alu(String endereco_propriedade_alu) {
        this.endereco_propriedade_alu = endereco_propriedade_alu;
    }

    public String getNumero_propriedade_alu() {
        return numero_propriedade_alu;
    }

    public void setNumero_propriedade_alu(String numero_propriedade_alu) {
        this.numero_propriedade_alu = numero_propriedade_alu;
    }

    public String getComplemento_propriedade_alu() {
        return complemento_propriedade_alu;
    }

    public void setComplemento_propriedade_alu(String complemento_propriedade_alu) {
        this.complemento_propriedade_alu = complemento_propriedade_alu;
    }

    public String getCiudade_propriedade_alu() {
        return ciudade_propriedade_alu;
    }

    public void setCiudade_propriedade_alu(String ciudade_propriedade_alu) {
        this.ciudade_propriedade_alu = ciudade_propriedade_alu;
    }

    public String getBarrio_propriedade_alu() {
        return barrio_propriedade_alu;
    }

    public void setBarrio_propriedade_alu(String barrio_propriedade_alu) {
        this.barrio_propriedade_alu = barrio_propriedade_alu;
    }

    public String getPreco_propriedade_alu() {
        return preco_propriedade_alu;
    }

    public void setPreco_propriedade_alu(String preco_propriedade_alu) {
        this.preco_propriedade_alu = preco_propriedade_alu;
    }

    public String getTipo_inmovel_propiedade_alu() {
        return tipo_inmovel_propiedade_alu;
    }

    public void setTipo_inmovel_propiedade_alu(String tipo_inmovel_propiedade_alu) {
        this.tipo_inmovel_propiedade_alu = tipo_inmovel_propiedade_alu;
    }

    public String getEstado_propriedade_alu() {
        return estado_propriedade_alu;
    }

    public void setEstado_propriedade_alu(String estado_propriedade_alu) {
        this.estado_propriedade_alu = estado_propriedade_alu;
    }

    public void imprimir_corretor_agendado() {
        System.out.println("Nome do Locador : " + super.nome_corretor);
        System.out.println("Sobre nome Locador" + super.sobrenome_corretor);
        System.out.println("O endereço do inmovel: " + this.endereco_propriedade_alu);
        System.out.println("O número do inmovel é: " + this.numero_propriedade_alu);
        System.out.println("O complemento do inmovel é: " + this.complemento_propriedade_alu);
        System.out.println("O barrio do inmovel é: " + this.barrio_propriedade_alu);
        System.out.println("O estado do inmovel é : " + this.estado_propriedade_alu);
        System.out.println("O preço do inmovel é: " + this.preco_propriedade_alu);

    }

}
